// Additional Animations and Interactive Effects
let techCanvas, techCtx;

// Initialize technology visualization canvas
function initTechVisualization() {
    techCanvas = document.getElementById('tech-canvas');
    if (!techCanvas) return;
    
    techCtx = techCanvas.getContext('2d');
    resizeTechCanvas();
    
    window.addEventListener('resize', resizeTechCanvas);
    animateDataFlow();
}

function resizeTechCanvas() {
    const container = techCanvas.parentElement;
    techCanvas.width = container.offsetWidth;
    techCanvas.height = container.offsetHeight;
}

// Data flow visualization
function animateDataFlow() {
    const nodes = [
        { x: 100, y: 150, label: 'Cloud', color: '#00d4ff' },
        { x: 300, y: 100, label: 'AI/ML', color: '#00ff88' },
        { x: 500, y: 200, label: 'Security', color: '#ff3366' },
        { x: 200, y: 300, label: 'Analytics', color: '#ffb800' },
        { x: 400, y: 250, label: 'IoT', color: '#ff6b35' }
    ];
    
    let particles = [];
    let time = 0;
    
    // Initialize particles
    for (let i = 0; i < 20; i++) {
        particles.push({
            x: Math.random() * techCanvas.width,
            y: Math.random() * techCanvas.height,
            vx: (Math.random() - 0.5) * 2,
            vy: (Math.random() - 0.5) * 2,
            life: Math.random()
        });
    }
    
    function drawTechVisualization() {
        if (!techCanvas || !techCtx) return;
        
        techCtx.clearRect(0, 0, techCanvas.width, techCanvas.height);
        time += 0.01;
        
        // Draw background grid
        drawGrid();
        
        // Update and draw particles
        updateParticles();
        
        // Draw connections between nodes
        drawConnections(nodes);
        
        // Draw nodes
        drawNodes(nodes);
        
        // Draw data streams
        drawDataStreams(nodes);
        
        requestAnimationFrame(drawTechVisualization);
    }
    
    function drawGrid() {
        techCtx.strokeStyle = 'rgba(0, 212, 255, 0.1)';
        techCtx.lineWidth = 1;
        
        for (let x = 0; x < techCanvas.width; x += 50) {
            techCtx.beginPath();
            techCtx.moveTo(x, 0);
            techCtx.lineTo(x, techCanvas.height);
            techCtx.stroke();
        }
        
        for (let y = 0; y < techCanvas.height; y += 50) {
            techCtx.beginPath();
            techCtx.moveTo(0, y);
            techCtx.lineTo(techCanvas.width, y);
            techCtx.stroke();
        }
    }
    
    function updateParticles() {
        particles.forEach((particle, index) => {
            particle.x += particle.vx;
            particle.y += particle.vy;
            particle.life -= 0.005;
            
            if (particle.x < 0 || particle.x > techCanvas.width) particle.vx *= -1;
            if (particle.y < 0 || particle.y > techCanvas.height) particle.vy *= -1;
            
            if (particle.life <= 0) {
                particles[index] = {
                    x: Math.random() * techCanvas.width,
                    y: Math.random() * techCanvas.height,
                    vx: (Math.random() - 0.5) * 2,
                    vy: (Math.random() - 0.5) * 2,
                    life: 1
                };
            }
            
            // Draw particle
            techCtx.beginPath();
            techCtx.arc(particle.x, particle.y, 2 * particle.life, 0, Math.PI * 2);
            techCtx.fillStyle = `rgba(0, 212, 255, ${particle.life * 0.5})`;
            techCtx.fill();
        });
    }
    
    function drawConnections(nodes) {
        for (let i = 0; i < nodes.length; i++) {
            for (let j = i + 1; j < nodes.length; j++) {
                const distance = Math.sqrt(
                    Math.pow(nodes[i].x - nodes[j].x, 2) + 
                    Math.pow(nodes[i].y - nodes[j].y, 2)
                );
                
                if (distance < 200) {
                    const opacity = (200 - distance) / 200;
                    techCtx.beginPath();
                    techCtx.moveTo(nodes[i].x, nodes[j].y);
                    techCtx.lineTo(nodes[j].x, nodes[j].y);
                    techCtx.strokeStyle = `rgba(0, 212, 255, ${opacity * 0.3})`;
                    techCtx.lineWidth = 2;
                    techCtx.stroke();
                }
            }
        }
    }
    
    function drawNodes(nodes) {
        nodes.forEach((node, index) => {
            const pulse = Math.sin(time * 3 + index) * 0.3 + 1;
            const radius = 25 * pulse;
            
            // Outer glow
            const gradient = techCtx.createRadialGradient(node.x, node.y, 0, node.x, node.y, radius * 2);
            gradient.addColorStop(0, node.color + '40');
            gradient.addColorStop(1, 'transparent');
            
            techCtx.fillStyle = gradient;
            techCtx.beginPath();
            techCtx.arc(node.x, node.y, radius * 2, 0, Math.PI * 2);
            techCtx.fill();
            
            // Main node
            techCtx.beginPath();
            techCtx.arc(node.x, node.y, radius, 0, Math.PI * 2);
            techCtx.fillStyle = node.color;
            techCtx.fill();
            
            // Inner ring
            techCtx.beginPath();
            techCtx.arc(node.x, node.y, radius * 0.7, 0, Math.PI * 2);
            techCtx.strokeStyle = '#ffffff';
            techCtx.lineWidth = 2;
            techCtx.stroke();
            
            // Label
            techCtx.fillStyle = '#ffffff';
            techCtx.font = '12px Inter, sans-serif';
            techCtx.textAlign = 'center';
            techCtx.fillText(node.label, node.x, node.y + radius + 20);
        });
    }
    
    function drawDataStreams(nodes) {
        for (let i = 0; i < nodes.length - 1; i++) {
            const start = nodes[i];
            const end = nodes[i + 1];
            
            // Animated data packets
            const progress = (Math.sin(time * 2 + i) + 1) / 2;
            const x = start.x + (end.x - start.x) * progress;
            const y = start.y + (end.y - start.y) * progress;
            
            techCtx.beginPath();
            techCtx.arc(x, y, 4, 0, Math.PI * 2);
            techCtx.fillStyle = '#00ff88';
            techCtx.fill();
            
            // Trail effect
            for (let j = 1; j <= 5; j++) {
                const trailProgress = Math.max(0, progress - j * 0.1);
                const trailX = start.x + (end.x - start.x) * trailProgress;
                const trailY = start.y + (end.y - start.y) * trailProgress;
                const trailOpacity = Math.max(0, 1 - j * 0.2);
                
                techCtx.beginPath();
                techCtx.arc(trailX, trailY, 2, 0, Math.PI * 2);
                techCtx.fillStyle = `rgba(0, 255, 136, ${trailOpacity})`;
                techCtx.fill();
            }
        }
    }
    
    drawTechVisualization();
}

// Service card hover effects with particles
function enhanceServiceCards() {
    const serviceCards = document.querySelectorAll('.service-card');
    
    serviceCards.forEach(card => {
        const canvas = document.createElement('canvas');
        canvas.className = 'service-particle-canvas';
        canvas.style.position = 'absolute';
        canvas.style.top = '0';
        canvas.style.left = '0';
        canvas.style.width = '100%';
        canvas.style.height = '100%';
        canvas.style.pointerEvents = 'none';
        canvas.style.opacity = '0';
        canvas.style.transition = 'opacity 0.3s ease';
        
        card.style.position = 'relative';
        card.appendChild(canvas);
        
        const ctx = canvas.getContext('2d');
        let particles = [];
        let animationId;
        
        function resizeCanvas() {
            canvas.width = card.offsetWidth;
            canvas.height = card.offsetHeight;
        }
        
        function createServiceParticles() {
            particles = [];
            for (let i = 0; i < 30; i++) {
                particles.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    vx: (Math.random() - 0.5) * 1,
                    vy: (Math.random() - 0.5) * 1,
                    life: Math.random(),
                    size: Math.random() * 3 + 1
                });
            }
        }
        
        function animateServiceParticles() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            particles.forEach(particle => {
                particle.x += particle.vx;
                particle.y += particle.vy;
                particle.life -= 0.01;
                
                if (particle.x < 0 || particle.x > canvas.width) particle.vx *= -1;
                if (particle.y < 0 || particle.y > canvas.height) particle.vy *= -1;
                
                if (particle.life <= 0) {
                    particle.life = 1;
                    particle.x = Math.random() * canvas.width;
                    particle.y = Math.random() * canvas.height;
                }
                
                ctx.beginPath();
                ctx.arc(particle.x, particle.y, particle.size * particle.life, 0, Math.PI * 2);
                ctx.fillStyle = `rgba(0, 212, 255, ${particle.life * 0.3})`;
                ctx.fill();
            });
            
            animationId = requestAnimationFrame(animateServiceParticles);
        }
        
        card.addEventListener('mouseenter', () => {
            resizeCanvas();
            createServiceParticles();
            canvas.style.opacity = '1';
            animateServiceParticles();
        });
        
        card.addEventListener('mouseleave', () => {
            canvas.style.opacity = '0';
            if (animationId) {
                cancelAnimationFrame(animationId);
            }
        });
    });
}

// Initialize all animations
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(() => {
        initTechVisualization();
        enhanceServiceCards();
    }, 1000);
}); 