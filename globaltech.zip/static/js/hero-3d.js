// 3D Hero Animation with Three.js
let scene, camera, renderer, servers = [], securityShields = [], networkNodes = [];
let mouseX = 0, mouseY = 0;
let isAnimating = true;

function initHero3D() {
    const canvas = document.getElementById('hero-canvas');
    if (!canvas) return;

    // Scene setup
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true, antialias: true });
    
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x000000, 0);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040, 0.3);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0x00d4ff, 1);
    directionalLight.position.set(10, 10, 5);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    scene.add(directionalLight);

    // Point lights for cybersecurity effect
    const pointLight1 = new THREE.PointLight(0x00ff88, 0.8, 30);
    pointLight1.position.set(-10, 5, 0);
    scene.add(pointLight1);

    const pointLight2 = new THREE.PointLight(0xff3366, 0.6, 25);
    pointLight2.position.set(10, -5, 5);
    scene.add(pointLight2);

    // Create server racks
    createServerRacks();
    
    // Create security shields
    createSecurityShields();
    
    // Create network visualization
    createNetworkNodes();
    
    // Create floating data particles
    createDataParticles();

    // Camera position
    camera.position.set(0, 2, 15);
    camera.lookAt(0, 0, 0);

    // Mouse movement interaction
    document.addEventListener('mousemove', onMouseMove, false);
    
    // Window resize handler
    window.addEventListener('resize', onWindowResize, false);

    // Start animation
    animate();
}

function createServerRacks() {
    const serverGeometry = new THREE.BoxGeometry(1.5, 3, 0.8);
    const serverMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x2c3e50,
        transparent: true,
        opacity: 0.8
    });

    for (let i = 0; i < 8; i++) {
        const server = new THREE.Mesh(serverGeometry, serverMaterial);
        server.position.x = (i - 4) * 3;
        server.position.y = -2;
        server.position.z = -5 + Math.random() * 3;
        server.castShadow = true;
        server.receiveShadow = true;
        
        // Add LED lights on servers
        const ledGeometry = new THREE.SphereGeometry(0.05, 16, 16);
        const ledMaterial = new THREE.MeshBasicMaterial({ 
            color: Math.random() > 0.5 ? 0x00ff88 : 0x00d4ff,
            emissive: Math.random() > 0.5 ? 0x00ff88 : 0x00d4ff,
            emissiveIntensity: 0.5
        });
        
        for (let j = 0; j < 6; j++) {
            const led = new THREE.Mesh(ledGeometry, ledMaterial);
            led.position.set(
                server.position.x + (Math.random() - 0.5) * 1.4,
                server.position.y + (j - 2.5) * 0.4,
                server.position.z + 0.41
            );
            scene.add(led);
        }
        
        servers.push(server);
        scene.add(server);
    }
}

function createSecurityShields() {
    const shieldGeometry = new THREE.ConeGeometry(1, 2, 6);
    const shieldMaterial = new THREE.MeshPhongMaterial({ 
        color: 0xff3366,
        transparent: true,
        opacity: 0.7,
        emissive: 0xff3366,
        emissiveIntensity: 0.2
    });

    for (let i = 0; i < 4; i++) {
        const shield = new THREE.Mesh(shieldGeometry, shieldMaterial);
        shield.position.x = (i - 1.5) * 4;
        shield.position.y = 2;
        shield.position.z = -2;
        shield.rotation.x = Math.PI;
        
        // Add wireframe overlay
        const wireframeGeometry = new THREE.EdgesGeometry(shieldGeometry);
        const wireframeMaterial = new THREE.LineBasicMaterial({ 
            color: 0xffffff,
            transparent: true,
            opacity: 0.5
        });
        const wireframe = new THREE.LineSegments(wireframeGeometry, wireframeMaterial);
        shield.add(wireframe);
        
        securityShields.push(shield);
        scene.add(shield);
    }
}

function createNetworkNodes() {
    const nodeGeometry = new THREE.SphereGeometry(0.2, 16, 16);
    const nodeMaterial = new THREE.MeshPhongMaterial({ 
        color: 0x00d4ff,
        emissive: 0x00d4ff,
        emissiveIntensity: 0.3,
        transparent: true,
        opacity: 0.8
    });

    // Create network nodes
    for (let i = 0; i < 12; i++) {
        const node = new THREE.Mesh(nodeGeometry, nodeMaterial);
        node.position.set(
            (Math.random() - 0.5) * 20,
            (Math.random() - 0.5) * 10,
            (Math.random() - 0.5) * 15
        );
        networkNodes.push(node);
        scene.add(node);
    }

    // Create connecting lines
    const lineMaterial = new THREE.LineBasicMaterial({ 
        color: 0x00d4ff,
        transparent: true,
        opacity: 0.3
    });

    for (let i = 0; i < networkNodes.length; i++) {
        for (let j = i + 1; j < networkNodes.length; j++) {
            const distance = networkNodes[i].position.distanceTo(networkNodes[j].position);
            if (distance < 8) {
                const geometry = new THREE.BufferGeometry().setFromPoints([
                    networkNodes[i].position,
                    networkNodes[j].position
                ]);
                const line = new THREE.Line(geometry, lineMaterial);
                scene.add(line);
            }
        }
    }
}

function createDataParticles() {
    const particleGeometry = new THREE.BufferGeometry();
    const particleCount = 500;
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
        positions[i * 3] = (Math.random() - 0.5) * 50;
        positions[i * 3 + 1] = (Math.random() - 0.5) * 30;
        positions[i * 3 + 2] = (Math.random() - 0.5) * 30;

        // Cybersecurity color palette
        const colorChoice = Math.random();
        if (colorChoice < 0.4) {
            colors[i * 3] = 0;     // R
            colors[i * 3 + 1] = 0.83; // G (00d4ff blue)
            colors[i * 3 + 2] = 1;   // B
        } else if (colorChoice < 0.7) {
            colors[i * 3] = 0;     // R
            colors[i * 3 + 1] = 1;   // G (00ff88 green)
            colors[i * 3 + 2] = 0.53; // B
        } else {
            colors[i * 3] = 1;     // R (ff3366 red)
            colors[i * 3 + 1] = 0.2; // G
            colors[i * 3 + 2] = 0.4; // B
        }
    }

    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    const particleMaterial = new THREE.PointsMaterial({
        size: 0.1,
        vertexColors: true,
        transparent: true,
        opacity: 0.6,
        blending: THREE.AdditiveBlending
    });

    const particles = new THREE.Points(particleGeometry, particleMaterial);
    scene.add(particles);
}

function onMouseMove(event) {
    mouseX = (event.clientX - window.innerWidth / 2) / 1000;
    mouseY = (event.clientY - window.innerHeight / 2) / 1000;
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

function animate() {
    if (!isAnimating) return;
    
    requestAnimationFrame(animate);

    const time = Date.now() * 0.001;

    // Animate servers
    servers.forEach((server, index) => {
        server.rotation.y = Math.sin(time + index) * 0.1;
        server.position.y = -2 + Math.sin(time * 2 + index) * 0.2;
    });

    // Animate security shields
    securityShields.forEach((shield, index) => {
        shield.rotation.y = time * 0.5 + index;
        shield.rotation.z = Math.sin(time + index) * 0.2;
        shield.position.y = 2 + Math.sin(time * 1.5 + index) * 0.3;
    });

    // Animate network nodes
    networkNodes.forEach((node, index) => {
        node.position.x += Math.sin(time + index) * 0.01;
        node.position.y += Math.cos(time * 1.2 + index) * 0.008;
        node.rotation.x = time * 0.5;
        node.rotation.y = time * 0.3;
    });

    // Camera movement based on mouse
    camera.position.x += (mouseX * 5 - camera.position.x) * 0.05;
    camera.position.y += (-mouseY * 3 - camera.position.y) * 0.05;
    camera.lookAt(0, 0, 0);

    // Rotate entire scene slightly
    scene.rotation.y = Math.sin(time * 0.1) * 0.1;

    renderer.render(scene, camera);
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(initHero3D, 500);
});

// Pause animation when not visible
document.addEventListener('visibilitychange', function() {
    isAnimating = !document.hidden;
    if (isAnimating) animate();
});

// Export for potential external use
window.Hero3D = {
    init: initHero3D,
    pause: () => { isAnimating = false; },
    resume: () => { isAnimating = true; animate(); }
}; 